package com.epilogue.dto.request.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdateInfoRequestDto {

    private String name;
    private String mobile;
}
