package com.epilogue.exception;

public class S3Exception {
}
